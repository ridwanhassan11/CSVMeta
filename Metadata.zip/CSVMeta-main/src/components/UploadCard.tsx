"use client";

import { useRef, useState } from "react";
import type { ImageItem } from "../types/image";

export default function UploadCard({
  onFilesSelected,
  images,
  selectedId,
  onSelect,
}: {
  onFilesSelected: (files: File[]) => void;
  images: ImageItem[];
  selectedId: string | null;
  onSelect: (id: string) => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  const active = images.find((image) => image.id === selectedId) || images[0];

  function handleFiles(fileList: FileList | null) {
    if (!fileList) return;
    onFilesSelected(Array.from(fileList));
  }

  return (
    <section className="rounded-[22px] border border-violet-100 bg-white p-3 shadow-[0_5px_18px_rgba(91,33,182,0.07)] dark:border-slate-800 dark:bg-slate-900 sm:p-4">
      <input ref={inputRef} type="file" accept="image/png,image/jpeg,image/webp" multiple className="hidden" onChange={(event) => handleFiles(event.target.files)} />
      <div
        onDragOver={(event) => { event.preventDefault(); setDragging(true); }}
        onDragLeave={() => setDragging(false)}
        onDrop={(event) => { event.preventDefault(); setDragging(false); handleFiles(event.dataTransfer.files); }}
        className={`relative flex h-[230px] items-center justify-center overflow-hidden rounded-2xl bg-violet-50 dark:bg-slate-800 sm:h-[260px] ${dragging ? "ring-2 ring-violet-500" : ""}`}
      >
        {active ? (
          <>
            <img src={active.previewUrl} alt={active.file.name} className="h-full w-full object-contain" />
            <span className="absolute left-3 top-3 rounded-full bg-violet-700 px-3 py-1.5 text-xs font-semibold text-white shadow">◉ Preview</span>
            <div className="absolute right-3 top-3 flex gap-2">
              <button onClick={() => inputRef.current?.click()} className="rounded-xl bg-white/90 px-3 py-2 text-sm font-semibold text-violet-700 shadow hover:bg-white">＋ Add images</button>
            </div>
            <button onClick={() => onSelect(images[Math.max(0, images.findIndex((item) => item.id === active.id) - 1)]?.id || active.id)} className="absolute left-3 top-1/2 grid h-10 w-10 -translate-y-1/2 place-items-center rounded-full bg-white/95 text-xl text-slate-800 shadow">‹</button>
            <button onClick={() => onSelect(images[(images.findIndex((item) => item.id === active.id) + 1) % images.length]?.id || active.id)} className="absolute right-3 top-1/2 grid h-10 w-10 -translate-y-1/2 rounded-full bg-white/95 text-xl text-slate-800 shadow">›</button>
          </>
        ) : (
          <button onClick={() => inputRef.current?.click()} className="flex h-full w-full flex-col items-center justify-center gap-3 border-2 border-dashed border-violet-200 text-center hover:bg-violet-100/60 dark:border-slate-600">
            <span className="grid h-14 w-14 place-items-center rounded-2xl bg-violet-600 text-3xl text-white shadow-lg">↑</span>
            <span className="text-sm font-semibold text-slate-800 dark:text-white">Drag &amp; drop images here, or <span className="text-violet-700 underline">browse</span></span>
            <span className="text-xs text-slate-500">PNG, JPG, JPEG, WEBP · Up to 100 images</span>
          </button>
        )}
      </div>
      <div className="mt-2 flex items-center gap-2 overflow-x-auto pb-1">
        {images.map((image) => (
          <button key={image.id} onClick={() => onSelect(image.id)} title={image.file.name} className={`h-[58px] w-[76px] shrink-0 overflow-hidden rounded-xl border-2 ${active?.id === image.id ? "border-violet-600 p-0.5" : "border-transparent opacity-80 hover:opacity-100"}`}>
            <img src={image.previewUrl} alt={image.file.name} className="h-full w-full rounded-lg object-cover" />
          </button>
        ))}
        <button onClick={() => inputRef.current?.click()} className="grid h-[58px] w-[58px] shrink-0 place-items-center rounded-xl border border-dashed border-violet-300 text-2xl text-violet-700 hover:bg-violet-50">+</button>
      </div>
    </section>
  );
}
