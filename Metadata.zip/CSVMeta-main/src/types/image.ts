export type ImageStatus = "pending" | "loading" | "done" | "error";

export type ImageItem = {
  id: string;
  file: File;
  previewUrl: string;
  status: ImageStatus;
  title?: string;
  description?: string;
  prompt?: string;
  keywords?: string[];
  error?: string;
};
