"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Sidebar from "@/components/Sidebar";
import UploadCard from "@/components/UploadCard";
import ControlsPanel, { type GenerationSettings, type Provider } from "@/components/ControlsPanel";
import ApiKeyModal from "@/components/ApiKeyModal";
import PreviewGrid from "@/components/PreviewGrid";
import ResultCard from "@/components/ResultCard";
import type { ImageItem } from "@/types/image";

const DEFAULT_SETTINGS: GenerationSettings = {
  provider: "gemini",
  geminiModel: "gemini-2.5-flash",
  mistralModel: "pixtral-large-latest",
  openaiModel: "gpt-4o",
  openrouterModel: "google/gemini-2.5-flash",
  mode: "metadata",
  platform: "general",
  titleLength: 140,
  keywordsCount: 43,
  extraInstructions: "",
  parallel: false,
};

const STORAGE_KEYS = "csvmeta-provider-keys-v1";
const HISTORY_KEY = "csvmeta-history-v1";

type SavedHistoryItem = {
  id: string;
  fileName: string;
  title?: string;
  description?: string;
  keywords?: string[];
  prompt?: string;
  createdAt: string;
};

const emptyKeys: Record<Provider, string[]> = {
  gemini: [],
  groq: [],
  mistral: [],
  openai: [],
  openrouter: [],
};

function makeId() {
  return typeof crypto !== "undefined" && "randomUUID" in crypto
    ? crypto.randomUUID()
    : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

function downloadCsv(images: ImageItem[]) {
  const completed = images.filter((image) => image.status === "done");
  if (!completed.length) return;
  const quote = (value: string) => `"${value.replace(/"/g, '""')}"`;
  const rows = [
    ["Filename", "Title", "Description", "Keywords", "Prompt"],
    ...completed.map((image) => [
      image.file.name,
      image.title || "",
      image.description || "",
      (image.keywords || []).join(", "),
      image.prompt || "",
    ]),
  ];
  const csv = "\uFEFF" + rows.map((row) => row.map(quote).join(",")).join("\r\n");
  const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = "csvmeta-export.csv";
  anchor.click();
  URL.revokeObjectURL(url);
}

export default function HomePage() {
  const [images, setImages] = useState<ImageItem[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [settings, setSettings] = useState<GenerationSettings>(DEFAULT_SETTINGS);
  const [savedKeys, setSavedKeys] = useState<Record<Provider, string[]>>(emptyKeys);
  const [activeKeys, setActiveKeys] = useState<Partial<Record<Provider, number>>>({});
  const [keysOpen, setKeysOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [history, setHistory] = useState<SavedHistoryItem[]>([]);
  const [hydrated, setHydrated] = useState(false);
  const [activeTab, setActiveTab] = useState<"Generate" | "Metadata" | "History" | "Templates" | "Settings">("Generate");

  useEffect(() => {
    try {
      const rawKeys = localStorage.getItem(STORAGE_KEYS);
      if (rawKeys) setSavedKeys({ ...emptyKeys, ...JSON.parse(rawKeys) });
      const rawHistory = localStorage.getItem(HISTORY_KEY);
      if (rawHistory) setHistory(JSON.parse(rawHistory));
    } catch {
      setNotice("Could not load saved browser settings.");
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem(STORAGE_KEYS, JSON.stringify(savedKeys));
  }, [hydrated, savedKeys]);

  useEffect(() => {
    if (!hydrated) return;
    localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(0, 100)));
  }, [hydrated, history]);

  const updateSettings = useCallback((patch: Partial<GenerationSettings>) => {
    setSettings((current) => ({ ...current, ...patch }));
  }, []);

  const addFiles = useCallback((files: File[]) => {
    const accepted = files.filter((file) => file.type.startsWith("image/"));
    if (!accepted.length) {
      setNotice("Please select PNG, JPG, JPEG, or WEBP image files.");
      return;
    }
    setImages((current) => {
      const next = accepted.slice(0, Math.max(0, 100 - current.length)).map((file) => ({
        id: makeId(),
        file,
        previewUrl: URL.createObjectURL(file),
        status: "pending" as const,
      }));
      if (!next.length) setNotice("You can upload up to 100 images at a time.");
      else setNotice(`${next.length} image(s) added.`);
      return [...current, ...next];
    });
  }, []);

  const updateImage = useCallback((id: string, patch: Partial<ImageItem>) => {
    setImages((current) => current.map((image) => image.id === id ? { ...image, ...patch } : image));
  }, []);

  const removeImage = useCallback((id: string) => {
    setImages((current) => {
      const target = current.find((image) => image.id === id);
      if (target) URL.revokeObjectURL(target.previewUrl);
      return current.filter((image) => image.id !== id);
    });
    setSelectedId((current) => current === id ? null : current);
  }, []);

  const getApiKey = useCallback((provider: Provider) => {
    const list = savedKeys[provider] || [];
    const index = activeKeys[provider] ?? (list.length ? list.length - 1 : -1);
    return index >= 0 ? list[index] || "" : "";
  }, [activeKeys, savedKeys]);

  const generateOne = useCallback(async (image: ImageItem) => {
    const apiKey = getApiKey(settings.provider);
    if (!apiKey) {
      updateImage(image.id, { status: "error", error: `No ${settings.provider} API key saved. Open API Keys to add one.` });
      return;
    }
    updateImage(image.id, { status: "loading", error: undefined });
    const form = new FormData();
    form.append("file", image.file);
    form.append("provider", settings.provider);
    form.append("geminiModel", settings.geminiModel);
    form.append("mistralModel", settings.mistralModel);
    form.append("openaiModel", settings.openaiModel);
    form.append("openrouterModel", settings.openrouterModel);
    form.append("apiKey", apiKey);
    form.append("mode", settings.mode);
    form.append("platform", settings.platform);
    form.append("titleLength", String(settings.titleLength));
    form.append("keywordsCount", String(settings.keywordsCount));
    form.append("extraInstructions", settings.extraInstructions);

    try {
      const response = await fetch("/api/generate", { method: "POST", body: form });
      const result = await response.json();
      if (!response.ok || !result.success) throw new Error(result.error || `Request failed (${response.status})`);
      if (settings.mode === "prompt") {
        updateImage(image.id, { status: "done", prompt: String(result.prompt || "") });
      } else {
        updateImage(image.id, {
          status: "done",
          title: String(result.title || ""),
          description: result.description === undefined ? undefined : String(result.description),
          keywords: Array.isArray(result.keywords) ? result.keywords.map(String) : [],
        });
      }
      setHistory((current) => [{
        id: image.id,
        fileName: image.file.name,
        title: result.title,
        description: result.description,
        keywords: result.keywords,
        prompt: result.prompt,
        createdAt: new Date().toISOString(),
      }, ...current].slice(0, 100));
    } catch (error) {
      updateImage(image.id, { status: "error", error: error instanceof Error ? error.message : "Generation failed." });
    }
  }, [getApiKey, settings, updateImage]);

  const generateAll = useCallback(async () => {
    const pending = images.filter((image) => image.status === "pending" || image.status === "error");
    if (!pending.length) {
      setNotice("Upload images first, or remove completed images before generating again.");
      return;
    }
    if (!getApiKey(settings.provider)) {
      setKeysOpen(true);
      setNotice(`Add a ${settings.provider} API key to continue.`);
      return;
    }
    setBusy(true);
    setNotice(`Generating metadata for ${pending.length} image(s)…`);
    try {
      if (settings.parallel) {
        await Promise.all(pending.map((image) => generateOne(image)));
      } else {
        for (const image of pending) await generateOne(image);
      }
      setNotice("Generation finished. Check each image for any errors.");
    } finally {
      setBusy(false);
    }
  }, [generateOne, getApiKey, images, settings.parallel, settings.provider]);

  const selectedImage = useMemo(
    () => images.find((image) => image.id === selectedId) || images.find((image) => image.status === "done") || null,
    [images, selectedId],
  );

  function addKey(provider: Provider, key: string) {
    setSavedKeys((current) => ({ ...current, [provider]: [...(current[provider] || []), key] }));
    setActiveKeys((current) => ({ ...current, [provider]: (savedKeys[provider] || []).length }));
  }

  function removeKey(provider: Provider, index: number) {
    setSavedKeys((current) => ({ ...current, [provider]: current[provider].filter((_, i) => i !== index) }));
    setActiveKeys((current) => ({ ...current, [provider]: undefined }));
  }

  function setActiveKey(provider: Provider, index: number) {
    setActiveKeys((current) => ({ ...current, [provider]: index }));
  }

  return (
    <div className="min-h-screen bg-[#fbfaff] text-slate-950 dark:bg-[#090914] dark:text-white">
      <Sidebar active={activeTab} onNavigate={setActiveTab} />
      <main className="min-h-screen px-4 py-5 md:ml-[210px] md:px-5">
        <div className="mx-auto max-w-[1600px]">
          <header className="mb-4 flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <span className="text-2xl text-violet-700">✦</span>
              <h1 className="text-xl font-extrabold tracking-tight">{activeTab === "Generate" ? "Generate Metadata" : activeTab}</h1>
            </div>
            <div className="flex items-center gap-4 text-slate-500">
              <button title="Help" className="text-xl">ⓘ</button>
              <button title="Notifications" className="text-xl">♧</button>
              <button onClick={() => setKeysOpen(true)} title="API Keys" className="grid h-9 w-9 place-items-center rounded-full bg-violet-100 font-bold text-violet-700">A</button>
            </div>
          </header>

          <nav className="mb-5 flex flex-wrap gap-2 md:hidden">
            {(["Generate", "Metadata", "History", "Templates", "Settings"] as const).map((tab) => (
              <button key={tab} onClick={() => setActiveTab(tab)} className={`rounded-full px-3 py-2 text-xs font-medium ${activeTab === tab ? "bg-violet-600 text-white" : "bg-white text-slate-600 dark:bg-slate-900 dark:text-slate-300"}`}>{tab}</button>
            ))}
          </nav>

          {activeTab === "History" ? (
            <section className="rounded-3xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900">
              <div className="mb-4 flex items-center justify-between"><h2 className="text-lg font-bold">Generation History</h2><button onClick={() => setHistory([])} className="text-sm text-rose-500">Clear history</button></div>
              {history.length ? <div className="space-y-3">{history.map((item) => <article key={`${item.id}-${item.createdAt}`} className="rounded-xl border border-slate-200 p-4 dark:border-slate-700"><p className="font-semibold">{item.fileName}</p>{item.title && <p className="mt-1 text-sm">{item.title}</p>}{item.prompt && <p className="mt-1 text-sm text-slate-500">{item.prompt}</p>}<p className="mt-2 text-xs text-slate-400">{new Date(item.createdAt).toLocaleString()}</p></article>)}</div> : <p className="text-sm text-slate-500">No generated items yet. Your future generations will appear here.</p>}
            </section>
          ) : activeTab === "Templates" ? (
            <section className="rounded-3xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900"><h2 className="text-lg font-bold">Prompt Templates</h2><p className="mt-2 text-sm text-slate-500">Choose a starter instruction to customize your generation style.</p><div className="mt-4 grid gap-3 md:grid-cols-2">{["Photorealistic stock image, clear subject and commercial use","Minimal composition, clean background, precise visual details","Editorial photography, natural lighting, authentic atmosphere","Detailed cinematic prompt with composition, color and camera angle"].map((template) => <button key={template} onClick={() => { updateSettings({ mode: "prompt", extraInstructions: template }); setActiveTab("Generate"); }} className="rounded-xl border border-slate-200 p-4 text-left text-sm hover:border-violet-400 dark:border-slate-700">{template}</button>)}</div></section>
          ) : activeTab === "Settings" ? (
            <section className="rounded-3xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900"><h2 className="text-lg font-bold">Settings</h2><p className="mt-2 text-sm text-slate-500">API keys are saved in this browser only. They are sent to the server only when you request image generation.</p><button onClick={() => setKeysOpen(true)} className="mt-4 rounded-xl bg-violet-600 px-4 py-2 text-sm font-semibold text-white">Manage API Keys</button></section>
          ) : (
            <>
              <div className="grid items-start gap-4 xl:grid-cols-[minmax(0,1.15fr)_minmax(390px,0.95fr)]">
                <div className="min-w-0">
                  <UploadCard onFilesSelected={addFiles} images={images} selectedId={selectedId} onSelect={setSelectedId} />
                </div>
                <div className="min-w-0">
                  <ControlsPanel settings={settings} onChange={updateSettings} onOpenKeys={() => setKeysOpen(true)} disabled={busy} />
                  <div className="mt-3 flex flex-wrap justify-end gap-2">
                    <button onClick={generateAll} disabled={!images.length || busy} className="rounded-xl bg-violet-700 px-5 py-3 text-sm font-bold text-white shadow-md shadow-violet-600/20 hover:bg-violet-800 disabled:opacity-40">{busy ? "Generating…" : "✦ Generate Metadata"}</button>
                  </div>
                </div>
              </div>
              <div className="mt-5">
                <div className="mb-3 flex flex-wrap items-center justify-end gap-2">
                  <span className="mr-auto text-sm text-slate-500">{images.length ? `${images.length} image(s) uploaded` : "Upload images to begin."}</span>
                  <button onClick={() => { images.forEach((image) => URL.revokeObjectURL(image.previewUrl)); setImages([]); setSelectedId(null); }} disabled={!images.length || busy} className="rounded-xl border border-violet-100 bg-white px-3 py-2 text-xs font-semibold text-slate-600 disabled:opacity-40">Clear All</button>
                  <button onClick={() => downloadCsv(images)} disabled={!images.some((image) => image.status === "done" && image.prompt === undefined)} className="rounded-xl bg-violet-700 px-4 py-2 text-xs font-bold text-white disabled:opacity-40">↓ Export CSV</button>
                </div>
                {notice && <p role="status" className="mb-2 text-sm text-slate-500 dark:text-slate-400">{notice}</p>}
                <PreviewGrid images={images} selectedId={selectedId} onSelect={setSelectedId} onRemove={removeImage} onUpdate={updateImage} />
                {images.length > 0 && <ResultCard image={selectedImage} onUpdate={updateImage} />}
              </div>
            </>
          )}
        </div>
      </main>
      <ApiKeyModal open={keysOpen} settings={settings} onChange={updateSettings} savedKeys={savedKeys} addKey={addKey} removeKey={removeKey} setActiveKey={setActiveKey} close={() => setKeysOpen(false)} />
    </div>
  );
}
