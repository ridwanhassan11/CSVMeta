# Metadata deployment notes

## Build entrypoint repair
The `/` route had been overwritten with the `PreviewGrid` component. The page is restored as the application entrypoint, and `ImageItem` now lives in `src/types/image.ts`, shared by the preview and result components.

## Required Vercel environment variables
- `KV_REST_API_URL`
- `KV_REST_API_TOKEN`
- `ADMIN_EMAILS` (comma-separated admin email addresses)

NextAuth's Google provider also needs the standard Google OAuth credentials and an Auth.js secret configured in the Vercel project environment. Keep all credentials in Vercel Environment Variables; do not commit `.env` files.

## Deploy
The project root in Vercel should point to the `app` directory in this repository (the directory containing `package.json`). Deployments run from the connected Git branch. After pushing the corrected files to `main`, check the Vercel Build Logs and confirm the new deployment is Ready.

## API provider keys
Gemini, Groq, Mistral, OpenAI, and OpenRouter keys are added by each user through the in-app API Keys dialog. They are stored in that user's browser and sent to the generation endpoint only when a generation is requested.
